from django.contrib import admin

# AI Services don't need admin interface as they are service classes
# Admin interface would be added here if we had models to manage
